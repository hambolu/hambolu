@extends('layouts.app')

@section('content')
<h1>about</h1>
@endsection
