<div class="jumbotron text-center">
  <div class="container">
    <h1>Welcome to Greenerworld</h1>
    <p class="lead">Join Greenerworld and make everything Green</p>
  </div>
</div>
