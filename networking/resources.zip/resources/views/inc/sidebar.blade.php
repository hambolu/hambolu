@section('sidebar')
<div class="well">
  <h3>sidebar</h3>
  this is the sidebar
</div>
@show
