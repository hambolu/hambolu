@extends('layouts.app')

@section('content')
<h1>contact</h1>
<p>
  
</p>
@endsection
